<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getSiteSetting('brand_name', 'BeamTheTeam'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-gray-100 text-gray-900">

    <!-- Top Announcement Bar -->
    <div class="bg-black text-white text-xs py-2 px-4 overflow-hidden">
        <div class="flex animate-scroll space-x-8 whitespace-nowrap">
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_1', 'SHIPPING TO TUNISIA ON ORDERS +$150'); ?></span>
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_2', 'EASY RETURNS'); ?></span>
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_3', 'FREE SHIPPING TO TUNISIA ON ORDERS +$150'); ?></span>
            <!-- Duplicated for seamless scroll -->
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_1', 'SHIPPING TO TUNISIA ON ORDERS +$150'); ?></span>
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_2', 'EASY RETURNS'); ?></span>
            <span class="flex items-center"><svg class="w-3 h-3 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11H9v3H8v2h1v3h2v-3h1v-2h-1V7z"></path></svg> <?php echo getSiteSetting('announcement_text_3', 'FREE SHIPPING TO TUNISIA ON ORDERS +$150'); ?></span>
        </div>
    </div>

    <!-- Header/Navigation Bar -->
    <header class="bg-white shadow-sm py-4 px-4 md:px-8 lg:px-12 sticky top-0 z-50">
        <div class="flex items-center justify-between relative">
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-button" class="text-gray-800 hover:text-black focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
            </div>
        
            <!-- Left Nav -->
            <nav class="hidden md:flex items-center space-x-2 md:space-x-4 lg:space-x-6 text-xs md:text-sm font-medium">
                <a href="index.php" class="hover:text-gray-700 rounded-md p-1 md:p-2 block">HOME</a>
                <div class="relative group">
                    <a href="shop.php" class="hover:text-gray-700 rounded-md p-1 md:p-2 block">SHOP</a>
                    
                    <!-- Mega Menu -->
                    <div class="absolute top-full left-0 w-screen h-[70vh] bg-white shadow-lg border-t border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                        <div class="max-w-7xl mx-auto px-2 md:px-4 lg:px-6 py-4 h-full">
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                <!-- Left Column - Categories -->
                                <div>
                                    <h3 class="text-lg font-bold text-black mb-4">CATEGORIES</h3>
                                    <ul class="space-y-3">
                                        <?php 
                                        $categories = getCategories();
                                        foreach ($categories as $category): 
                                        ?>
                                        <li>
                                            <a href="shop.php?category=<?php echo $category['id']; ?>" class="text-gray-700 hover:text-black transition-colors duration-200 flex items-center">
                                                <img src="<?php echo $category['image']; ?>" alt="<?php echo $category['name']; ?>" class="w-12 h-12 object-cover rounded mr-3">
                                                <?php echo $category['name']; ?>
                                            </a>
                                        </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                
                                <!-- Middle Column - Collections -->
                                <div>
                                    <h3 class="text-lg font-bold text-black mb-4">COLLECTIONS</h3>
                                    <ul class="space-y-3">
                                        <?php 
                                        $collections = getCollections();
                                        foreach ($collections as $collection): 
                                        ?>
                                        <li>
                                            <a href="shop.php?collection=<?php echo $collection['id']; ?>" class="text-gray-700 hover:text-black transition-colors duration-200 flex items-center">
                                                <img src="<?php echo $collection['image']; ?>" alt="<?php echo $collection['name']; ?>" class="w-12 h-12 object-cover rounded mr-3">
                                                <?php echo $collection['name']; ?>
                                            </a>
                                        </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                
                                <!-- Right Column - Best Seller Products -->
                                <div>
                                    <h3 class="text-lg font-bold text-black mb-4">BEST SELLERS</h3>
                                    <div class="grid grid-cols-2 gap-3">
                                        <?php 
                                        $bestsellerProducts = getProducts(['bestseller' => true, 'limit' => 4]);
                                        foreach ($bestsellerProducts as $product): 
                                            $productImages = getProductImagesForSlider($product['id']);
                                            $primaryImage = $productImages[0]['image_path'] ?? 'images/placeholder.jpg';
                                        ?>
                                        <div class="group">
                                            <a href="product-view.php?id=<?php echo $product['id']; ?>" class="block">
                                                <img src="<?php echo $primaryImage; ?>" alt="<?php echo $product['name']; ?>" class="w-24 h-25 object-cover group-hover:scale-105 transition-transform duration-300 rounded">
                                                <p class="text-xs font-medium text-gray-700 mt-2 truncate"><?php echo $product['name']; ?></p>
                                                <p class="text-xs text-gray-500"><?php echo formatPrice($product['sale_price'] ?? $product['price']); ?></p>
                                            </a>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="collections.php" class="hover:text-gray-700 rounded-md p-1 md:p-2 hidden sm:block">COLLECTIONS</a>
                <a href="about.php" class="hover:text-gray-700 rounded-md p-1 md:p-2 hidden xl:block">ABOUT US</a>
            </nav>

            <!-- Logo -->
            <div class="absolute left-1/2 transform -translate-x-1/2">
                <a href="index.php" id="brand-logo" class="text-lg md:text-xl lg:text-2xl font-bold tracking-wider text-gray-800 rounded-md p-1 md:p-2 glitch-text relative select-none flex items-center gap-2" style="display:inline-block;">
                    <span class="logo-glitch-stack">
                        <img src="<?php echo getSiteSetting('brand_logo', 'images/logo.webp'); ?>" alt="Logo 1" class="brand-logo-img w-16 h-16 md:w-20 md:h-20 mx-auto transition-transform duration-300 glitch-logo glitch-logo-1" style="vertical-align:middle; position:absolute; left:0; top:0;"/>
                        <img src="<?php echo getSiteSetting('brand_logo2', 'images/logo2.png'); ?>" alt="Logo 2" class="brand-logo-img w-16 h-16 md:w-20 md:h-20 mx-auto transition-transform duration-300 glitch-logo glitch-logo-2" style="vertical-align:middle; position:absolute; left:0; top:0;"/>
                    </span>
                </a>
            </div>
            <style>
.logo-glitch-stack {
    position: relative;
    width: 5rem;
    height: 5rem;
    display: inline-block;
}
.glitch-logo {
    position: absolute;
    left: 0; top: 0;
    width: 100%; height: 100%;
    opacity: 0;
    filter: drop-shadow(0 0 2px #0ff) drop-shadow(0 0 4px #f0f);
    animation: logo-glitch-fade 3s infinite steps(1);
}
.glitch-logo-1 {
    animation-delay: 0s;
}
.glitch-logo-2 {
    animation-delay: 1.5s;
}
@keyframes logo-glitch-fade {
    0%   { opacity: 1; filter: none; transform: none; }
    10%  { opacity: 1; filter: blur(1px) brightness(1.2) drop-shadow(0 0 6px #0ff); transform: skewX(2deg) scale(1.05); }
    12%  { opacity: 1; filter: none; transform: none; }
    48.9% { opacity: 1; }
    49%  { opacity: 0; }
    100% { opacity: 0; }
}
</style>

            <!-- Right Icons -->
            <div class="flex items-center space-x-2 md:space-x-4 lg:space-x-6">
                <!-- Wishlist button (temporarily hidden via CSS - preserved for future use) -->
                <button id="wishlist-button" class="text-gray-600 hover:text-gray-800 rounded-md p-1 md:p-2" aria-label="Wishlist">
                    <svg class="w-4 h-4 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"></path></svg>
                </button>
                <a href="view_cart.php" class="text-gray-600 hover:text-gray-800 rounded-md p-1 md:p-2 relative" aria-label="Cart">
                    <svg class="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                      <circle cx="9" cy="20" r="1.5"/>
                      <circle cx="18" cy="20" r="1.5"/>
                      <path stroke-linecap="round" stroke-linejoin="round" d="M3 4h2l2.4 12.29a2 2 0 0 0 2 1.71h7.2a2 2 0 0 0 2-1.71L21 7H6"/>
                    </svg>
                    <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center cart-count">
                        <?php 
                        $cartItems = getCartItems();
                        $totalItems = array_sum(array_column($cartItems, 'quantity'));
                        echo $totalItems;
                        ?>
                    </span>
                </a>
                <button id="search-button" class="text-gray-600 hover:text-gray-800 rounded-md p-1 md:p-2" aria-label="Search">
                    <svg class="w-4 h-4 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"></path></svg>
                </button>
            </div>
        </div>

        <!-- Mobile Menu (Off-canvas) -->
        <div id="mobile-menu" class="fixed top-0 left-0 w-full h-full bg-white z-50 transform -translate-x-full transition-transform duration-300 ease-in-out md:hidden overflow-y-auto">
            <div class="flex justify-end p-4 border-b border-gray-200">
                <button id="close-menu-button" class="text-gray-800 hover:text-black focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            
            <div class="px-6 py-4">
                <!-- Quick Links -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-black mb-4">QUICK LINKS</h3>
                    <ul class="space-y-3">
                        <li><a href="index.php" class="text-gray-700 hover:text-black transition-colors duration-200 block py-2">HOME</a></li>
                        <li><a href="shop.php" class="text-gray-700 hover:text-black transition-colors duration-200 block py-2">ALL PRODUCTS</a></li>
                        <li><a href="collections.php" class="text-gray-700 hover:text-black transition-colors duration-200 block py-2">COLLECTIONS</a></li>
                        <li><a href="#" class="text-gray-700 hover:text-black transition-colors duration-200 block py-2">FAQS</a></li>
                    </ul>
                </div>

                <!-- Categories Section -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-black mb-4">CATEGORIES</h3>
                    <div class="space-y-3">
                        <?php 
                        $categories = getCategories();
                        foreach ($categories as $category): 
                        ?>
                        <a href="shop.php?category=<?php echo $category['id']; ?>" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <img src="<?php echo $category['image']; ?>" alt="<?php echo $category['name']; ?>" class="w-12 h-12 object-cover rounded mr-4">
                            <div>
                                <p class="font-medium text-gray-900"><?php echo $category['name']; ?></p>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Collections Section -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-black mb-4">COLLECTIONS</h3>
                    <div class="space-y-3">
                        <?php 
                        $collections = getCollections();
                        foreach ($collections as $collection): 
                        ?>
                        <a href="shop.php?collection=<?php echo $collection['id']; ?>" class="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <img src="<?php echo $collection['image']; ?>" alt="<?php echo $collection['name']; ?>" class="w-12 h-12 object-cover rounded mr-4">
                            <div>
                                <p class="font-medium text-gray-900"><?php echo $collection['name']; ?></p>
                                <p class="text-sm text-gray-500"><?php echo $collection['description']; ?></p>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Best Sellers Section -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-black mb-4">BEST SELLERS</h3>
                    <div class="grid grid-cols-2 gap-3">
                        <?php 
                        $bestsellerProducts = getProducts(['bestseller' => true, 'limit' => 4]);
                        foreach ($bestsellerProducts as $product): 
                            $productImages = getProductImagesForSlider($product['id']);
                            $primaryImage = $productImages[0]['image_path'] ?? 'images/placeholder.jpg';
                        ?>
                        <a href="product-view.php?id=<?php echo $product['id']; ?>" class="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                            <img src="<?php echo $primaryImage; ?>" alt="<?php echo $product['name']; ?>" class="w-full h-32 object-cover rounded mb-2">
                            <p class="text-sm font-medium text-gray-900 truncate"><?php echo $product['name']; ?></p>
                            <p class="text-sm text-gray-500"><?php echo formatPrice($product['sale_price'] ?? $product['price']); ?></p>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </header> 