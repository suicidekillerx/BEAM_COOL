<?php
// Prevent double inclusion
if (defined('FUNCTIONS_LOADED')) {
    return;
}
define('FUNCTIONS_LOADED', true);

// Start output buffering to prevent any output before JSON
ob_start();

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

function require_admin_auth() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['admin_logged_in'])) {
        header('Location: /admin/index.php');
        exit();
    }
}

// Get site setting
function getSiteSetting($key, $default = '') {
    static $cachedSettings = [];
    
    if (isset($cachedSettings[$key])) {
        return $cachedSettings[$key];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    $value = $result ? $result['setting_value'] : $default;
    
    $cachedSettings[$key] = $value;
    return $value;
}

// Get all categories
function getCategories() {
    static $cachedCategories = null;
    
    if ($cachedCategories !== null) {
        return $cachedCategories;
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute();
    $cachedCategories = $stmt->fetchAll();
    
    return $cachedCategories;
}

// Get all collections
function getCollections() {
    static $cachedCollections = null;
    
    if ($cachedCollections !== null) {
        return $cachedCollections;
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM collections WHERE is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute();
    $cachedCollections = $stmt->fetchAll();
    
    return $cachedCollections;
}

// Get products with filters
function getProducts($filters = []) {
    $pdo = getDBConnection();
    
    $sql = "SELECT p.*, c.name as category_name, col.name as collection_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN collections col ON p.collection_id = col.id 
            WHERE p.is_active = 1";
    
    $params = [];
    
    // Category filter - handle both single value and array
    if (!empty($filters['category'])) {
        if (is_array($filters['category'])) {
            $placeholders = str_repeat('?,', count($filters['category']) - 1) . '?';
            $sql .= " AND p.category_id IN ($placeholders)";
            $params = array_merge($params, $filters['category']);
        } else {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category'];
        }
    }
    
    // Collection filter - handle both single value and array
    if (!empty($filters['collection'])) {
        if (is_array($filters['collection'])) {
            $placeholders = str_repeat('?,', count($filters['collection']) - 1) . '?';
            $sql .= " AND p.collection_id IN ($placeholders)";
            $params = array_merge($params, $filters['collection']);
        } else {
            $sql .= " AND p.collection_id = ?";
            $params[] = $filters['collection'];
        }
    }
    
    if (!empty($filters['featured'])) {
        $sql .= " AND p.is_featured = 1";
    }
    
    if (!empty($filters['bestseller'])) {
        $sql .= " AND p.is_bestseller = 1";
    }
    
    if (!empty($filters['on_sale'])) {
        $sql .= " AND p.is_on_sale = 1";
    }
    
    if (!empty($filters['search'])) {
        $sql .= " AND (p.name LIKE ? OR p.description LIKE ? OR p.short_description LIKE ?)";
        $searchTerm = '%' . $filters['search'] . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // Size filter - handle both single value and array
    if (!empty($filters['size'])) {
        if (is_array($filters['size'])) {
            $placeholders = str_repeat('?,', count($filters['size']) - 1) . '?';
            $sql .= " AND EXISTS (
                SELECT 1 FROM product_sizes ps 
                WHERE ps.product_id = p.id 
                AND LOWER(ps.size) IN ($placeholders)
                AND ps.stock_quantity > 0
            )";
            $sizeParams = array_map('strtolower', $filters['size']);
            $params = array_merge($params, $sizeParams);
        } else {
            $sql .= " AND EXISTS (
                SELECT 1 FROM product_sizes ps 
                WHERE ps.product_id = p.id 
                AND LOWER(ps.size) = ? 
                AND ps.stock_quantity > 0
            )";
            $params[] = strtolower($filters['size']);
        }
    }
    
    $sql .= " ORDER BY p.created_at DESC";
    
    if (!empty($filters['limit'])) {
        $sql .= " LIMIT " . (int)$filters['limit'];
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// Get single product by ID
function getProduct($id) {
    static $cachedProducts = [];
    
    if (isset($cachedProducts[$id])) {
        return $cachedProducts[$id];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT p.*, c.name as category_name, col.name as collection_name 
                          FROM products p 
                          LEFT JOIN categories c ON p.category_id = c.id 
                          LEFT JOIN collections col ON p.collection_id = col.id 
                          WHERE p.id = ? AND p.is_active = 1");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    $cachedProducts[$id] = $product;
    return $product;
}

// Get product images
function getProductImages($productId) {
    static $cachedProductImages = [];
    
    if (isset($cachedProductImages[$productId])) {
        return $cachedProductImages[$productId];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute([$productId]);
    $images = $stmt->fetchAll();
    
    $cachedProductImages[$productId] = $images;
    return $images;
}

// Get product sizes and stock
function getProductSizes($productId) {
    static $cachedSizes = [];
    
    if (isset($cachedSizes[$productId])) {
        return $cachedSizes[$productId];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM product_sizes WHERE product_id = ? AND stock_quantity > 0 ORDER BY FIELD(size, 'XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL')");
    $stmt->execute([$productId]);
    $sizes = $stmt->fetchAll();
    
    $cachedSizes[$productId] = $sizes;
    return $sizes;
}

// Get social media links
function getSocialMedia() {
    static $cachedSocialMedia = null;
    
    if ($cachedSocialMedia !== null) {
        return $cachedSocialMedia;
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM social_media WHERE is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute();
    $cachedSocialMedia = $stmt->fetchAll();
    
    return $cachedSocialMedia;
}

// Get footer sections and links
function getFooterData() {
    static $cachedFooterData = null;
    
    if ($cachedFooterData !== null) {
        return $cachedFooterData;
    }
    
    $pdo = getDBConnection();
    
    // Get sections
    $stmt = $pdo->prepare("SELECT * FROM footer_sections WHERE is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute();
    $sections = $stmt->fetchAll();
    
    // Get links for each section
    foreach ($sections as &$section) {
        $stmt = $pdo->prepare("SELECT * FROM footer_links WHERE section_id = ? AND is_active = 1 ORDER BY sort_order ASC");
        $stmt->execute([$section['id']]);
        $section['links'] = $stmt->fetchAll();
    }
    
    $cachedFooterData = $sections;
    return $cachedFooterData;
}

// Get video section data
function getVideoSection() {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM video_section WHERE is_active = 1 LIMIT 1");
    $stmt->execute();
    return $stmt->fetch();
}

// Cart functions
function addToCart($productId, $size, $quantity = 1) {
    try {
        $pdo = getDBConnection();
        $sessionId = session_id();
        
        // Check if item already exists in cart
        $stmt = $pdo->prepare("SELECT id, quantity FROM cart_items WHERE session_id = ? AND product_id = ? AND size = ?");
        $stmt->execute([$sessionId, $productId, $size]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            // Update quantity
            $newQuantity = $existing['quantity'] + $quantity;
            $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newQuantity, $existing['id']]);
        } else {
            // Add new item
            $stmt = $pdo->prepare("INSERT INTO cart_items (session_id, product_id, size, quantity) VALUES (?, ?, ?, ?)");
            $stmt->execute([$sessionId, $productId, $size, $quantity]);
        }
        
        return true;
    } catch (Exception $e) {
        throw $e;
    }
}

function getCartItems() {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    $stmt = $pdo->prepare("SELECT ci.*, p.name, p.price, p.sale_price, p.color 
                          FROM cart_items ci 
                          JOIN products p ON ci.product_id = p.id 
                          WHERE ci.session_id = ?");
    $stmt->execute([$sessionId]);
    $items = $stmt->fetchAll();
    
    // Add formatted price and image to each item
    foreach ($items as &$item) {
        $item['price_formatted'] = formatPrice($item['sale_price'] ?? $item['price']);
        $item['total_price'] = ($item['sale_price'] ?? $item['price']) * $item['quantity'];
        $item['image'] = getProductImage($item['product_id']);
    }
    
    return $items;
}

function updateCartItem($cartItemId, $quantity) {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    if ($quantity <= 0) {
        // Remove item
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE id = ? AND session_id = ?");
        $stmt->execute([$cartItemId, $sessionId]);
    } else {
        // Update quantity
        $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ? AND session_id = ?");
        $stmt->execute([$quantity, $cartItemId, $sessionId]);
    }
    
    return true;
}

function clearCart() {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    $stmt = $pdo->prepare("DELETE FROM cart_items WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    
    return true;
}

// Wishlist functions (temporarily hidden via CSS - code preserved for future use)
function addToWishlist($productId) {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    // Check if already in wishlist
    $stmt = $pdo->prepare("SELECT id FROM wishlist_items WHERE session_id = ? AND product_id = ?");
    $stmt->execute([$sessionId, $productId]);
    
    if (!$stmt->fetch()) {
        $stmt = $pdo->prepare("INSERT INTO wishlist_items (session_id, product_id) VALUES (?, ?)");
        $stmt->execute([$sessionId, $productId]);
    }
    
    return true;
}

function removeFromWishlist($productId) {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    $stmt = $pdo->prepare("DELETE FROM wishlist_items WHERE session_id = ? AND product_id = ?");
    $stmt->execute([$sessionId, $productId]);
    
    return true;
}

function getWishlistItems() {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    $stmt = $pdo->prepare("SELECT wi.*, p.name, p.price, p.sale_price, p.color 
                          FROM wishlist_items wi 
                          JOIN products p ON wi.product_id = p.id 
                          WHERE wi.session_id = ?");
    $stmt->execute([$sessionId]);
    return $stmt->fetchAll();
}

function isInWishlist($productId) {
    $pdo = getDBConnection();
    $sessionId = session_id();
    
    $stmt = $pdo->prepare("SELECT id FROM wishlist_items WHERE session_id = ? AND product_id = ?");
    $stmt->execute([$sessionId, $productId]);
    
    return $stmt->fetch() ? true : false;
}

// Utility functions
function formatPrice($price) {
    return number_format($price, 3) . ' DTN';
}

function getProductImage($productId, $primary = true) {
    static $cachedImages = [];
    
    $cacheKey = $productId . '_' . ($primary ? 'primary' : 'all');
    
    if (isset($cachedImages[$cacheKey])) {
        return $cachedImages[$cacheKey];
    }
    
    $pdo = getDBConnection();
    $sql = "SELECT image_path FROM product_images WHERE product_id = ?";
    if ($primary) {
        $sql .= " AND is_primary = 1";
    }
    $sql .= " ORDER BY is_primary DESC, sort_order ASC LIMIT 1";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$productId]);
    $result = $stmt->fetch();
    
    $imagePath = $result ? $result['image_path'] : 'images/placeholder.jpg';
    $cachedImages[$cacheKey] = $imagePath;
    
    return $imagePath;
}

function getProductImagesForSlider($productId) {
    static $cachedSliderImages = [];
    
    if (isset($cachedSliderImages[$productId])) {
        return $cachedSliderImages[$productId];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT image_path FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC LIMIT 2");
    $stmt->execute([$productId]);
    $images = $stmt->fetchAll();
    
    $cachedSliderImages[$productId] = $images;
    return $images;
}

// Get related products based on category and collection
function getRelatedProducts($currentProductId, $categoryId, $collectionId, $limit = 4) {
    $pdo = getDBConnection();
    
    // Build query to get products from same category or collection, excluding current product
    $sql = "SELECT p.*, c.name as category_name, col.name as collection_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN collections col ON p.collection_id = col.id 
            WHERE p.is_active = 1 AND p.id != ?";
    
    $params = [$currentProductId];
    
    // Add category and collection conditions
    $conditions = [];
    if ($categoryId) {
        $conditions[] = "p.category_id = ?";
        $params[] = $categoryId;
    }
    if ($collectionId) {
        $conditions[] = "p.collection_id = ?";
        $params[] = $collectionId;
    }
    
    // If we have conditions, add them to the query
    if (!empty($conditions)) {
        $sql .= " AND (" . implode(" OR ", $conditions) . ")";
    }
    
    $sql .= " ORDER BY p.is_featured DESC, p.is_bestseller DESC, p.created_at DESC LIMIT " . (int)$limit;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $relatedProducts = $stmt->fetchAll();
    
    // If we don't have enough related products, fill with other products
    if (count($relatedProducts) < $limit) {
        $remaining = $limit - count($relatedProducts);
        $existingIds = array_merge([$currentProductId], array_column($relatedProducts, 'id'));
        
        if (!empty($existingIds)) {
            $placeholders = str_repeat('?,', count($existingIds) - 1) . '?';
            
            $sql = "SELECT p.*, c.name as category_name, col.name as collection_name 
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.id 
                    LEFT JOIN collections col ON p.collection_id = col.id 
                    WHERE p.is_active = 1 AND p.id NOT IN ($placeholders)
                    ORDER BY p.is_featured DESC, p.is_bestseller DESC, p.created_at DESC 
                    LIMIT " . (int)$remaining;
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($existingIds);
            $additionalProducts = $stmt->fetchAll();
            
            $relatedProducts = array_merge($relatedProducts, $additionalProducts);
        }
    }
    
    return array_slice($relatedProducts, 0, $limit);
}

// AJAX handlers moved to ajax_handler.php for better session management

// Generate unique order number
function generateOrderNumber() {
    $prefix = 'BEAM';
    $timestamp = date('YmdHis');
    $random = strtoupper(substr(md5(uniqid()), 0, 4));
    return $prefix . $timestamp . $random;
}

// Create new order
function createOrder($orderData) {
    $pdo = getDBConnection();
    
    try {
        $pdo->beginTransaction();
        
        // Create order
        $orderNumber = generateOrderNumber();
        $stmt = $pdo->prepare("
            INSERT INTO orders (
                order_number, session_id, customer_name, customer_email, customer_phone,
                shipping_address, shipping_city, shipping_postal_code, shipping_notes,
                subtotal, tax, shipping_cost, total, payment_method, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $orderNumber,
            session_id(),
            $orderData['customer_name'],
            $orderData['customer_email'],
            $orderData['customer_phone'],
            $orderData['shipping_address'],
            $orderData['shipping_city'],
            $orderData['shipping_postal_code'],
            $orderData['shipping_notes'],
            $orderData['subtotal'],
            $orderData['tax'],
            $orderData['shipping_cost'],
            $orderData['total'],
            'cash_on_delivery',
            $orderData['notes'] ?? null
        ]);
        
        $orderId = $pdo->lastInsertId();
        
        // Get cart items and create order items
        $cartItems = getCartItems();
        foreach ($cartItems as $item) {
            $stmt = $pdo->prepare("
                INSERT INTO order_items (
                    order_id, product_id, product_name, product_price, product_sale_price,
                    size, quantity, total_price
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['name'],
                $item['price'],
                $item['sale_price'],
                $item['size'],
                $item['quantity'],
                $item['total_price']
            ]);
        }
        
        // Clear cart after successful order
        clearCart();
        
        $pdo->commit();
        return $orderNumber;
        
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
}

// Get order by order number
function getOrder($orderNumber) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT * FROM orders WHERE order_number = ? AND session_id = ?
    ");
    $stmt->execute([$orderNumber, session_id()]);
    return $stmt->fetch();
}

// Get order items
function getOrderItems($orderId) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT oi.*, p.name as product_name, p.color 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.id 
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll();
    
    // Add product images to each item
    foreach ($items as &$item) {
        if ($item['product_id']) {
            $item['image'] = getProductImage($item['product_id']);
        } else {
            $item['image'] = 'images/placeholder.jpg';
        }
    }
    
    return $items;
}

// Get Tunisia cities/governorates
function getTunisiaCities() {
    return [
        'Tunis', 'Sfax', 'Sousse', 'Kairouan', 'Bizerte', 'Gabès', 'Ariana', 'Gafsa', 'Monastir', 'La Marsa',
        'Ben Arous', 'Nabeul', 'Hammamet', 'Tozeur', 'Mahdia', 'Zaghouan', 'Siliana', 'Le Kef', 'Jendouba', 'Béja',
        'Kasserine', 'Sidi Bouzid', 'Kebili', 'Tataouine', 'Médenine', 'Tataouine', 'Zarzis', 'Djerba', 'Tabarka', 'Hammam-Lif'
    ];
}

// Get about page content by section and key
function getAboutContent($section, $key = null) {
    static $cachedContent = [];
    
    $cacheKey = $section . ($key ? '_' . $key : '');
    
    if (isset($cachedContent[$cacheKey])) {
        return $cachedContent[$cacheKey];
    }
    
    $pdo = getDBConnection();
    
    if ($key) {
        // Get specific content
        $stmt = $pdo->prepare("SELECT content_value, content_type FROM aboutus WHERE section_name = ? AND content_key = ? AND is_active = 1");
        $stmt->execute([$section, $key]);
        $result = $stmt->fetch();
        
        if ($result) {
            $cachedContent[$cacheKey] = $result['content_value'];
            return $result['content_value'];
        }
        return '';
    } else {
        // Get all content for a section
        $stmt = $pdo->prepare("SELECT content_key, content_value, content_type FROM aboutus WHERE section_name = ? AND is_active = 1 ORDER BY sort_order ASC");
        $stmt->execute([$section]);
        $results = $stmt->fetchAll();
        
        $sectionContent = [];
        foreach ($results as $row) {
            $sectionContent[$row['content_key']] = $row['content_value'];
        }
        
        $cachedContent[$cacheKey] = $sectionContent;
        return $sectionContent;
    }
}

// Get all about page content organized by sections
function getAllAboutContent($editable = false) {
    static $cachedAllContent = [];
    
    $cacheKey = $editable ? 'editable' : 'regular';
    
    if (isset($cachedAllContent[$cacheKey])) {
        return $cachedAllContent[$cacheKey];
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT section_name, content_key, content_value, content_type, sort_order FROM aboutus WHERE is_active = 1 ORDER BY section_name, sort_order ASC");
    $stmt->execute();
    $results = $stmt->fetchAll();
    
    $allContent = [];
    foreach ($results as $row) {
        if (!isset($allContent[$row['section_name']])) {
            $allContent[$row['section_name']] = [];
        }
        
        // For editable mode, we store the full content information
        if ($editable) {
            if (!isset($allContent[$row['section_name']][$row['content_key']])) {
                $allContent[$row['section_name']][$row['content_key']] = $row['content_value'];
            }
        } else {
            $allContent[$row['section_name']][$row['content_key']] = $row['content_value'];
        }
    }
    
    $cachedAllContent[$cacheKey] = $allContent;
    return $allContent;
}

// Update about page content
function updateAboutContent($section, $key, $value) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("UPDATE aboutus SET content_value = ?, updated_at = CURRENT_TIMESTAMP WHERE section_name = ? AND content_key = ?");
    $result = $stmt->execute([$value, $section, $key]);
    
    // Clear cache
    static $cachedContent = [];
    $cacheKey = $section . '_' . $key;
    unset($cachedContent[$cacheKey]);
    unset($cachedContent[$section]);
    
    return $result;
}

// Insert new about page content
function insertAboutContent($section, $key, $type, $value, $sortOrder = 0) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO aboutus (section_name, content_key, content_type, content_value, sort_order) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE content_value = VALUES(content_value), content_type = VALUES(content_type), sort_order = VALUES(sort_order), updated_at = CURRENT_TIMESTAMP");
    $result = $stmt->execute([$section, $key, $type, $value, $sortOrder]);
    
    // Clear cache
    static $cachedContent = [];
    $cacheKey = $section . '_' . $key;
    unset($cachedContent[$cacheKey]);
    unset($cachedContent[$section]);
    
    return $result;
}

?>