<?php
require_once __DIR__.'/../includes/functions.php';
// require_admin_auth();  // Temporarily disabled

$aboutContent = getAllAboutContent(true); // Get editable content
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?php echo getSiteSetting('brand_name', 'BeamTheTeam'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="admin.css">
    <script src="../script.js" defer></script>
    <style>
        [contenteditable="true"] {
            outline: 2px dashed rgba(59, 130, 246, 0.3);
            transition: all 0.2s;
            min-height: 40px;
            padding: 8px;
        }

        [contenteditable="true"]:hover {
            outline-color: rgba(59, 130, 246, 0.6);
            background: rgba(59, 130, 246, 0.05);
        }

        [contenteditable="true"]:focus {
            outline-color: rgba(59, 130, 246, 1);
            background: white;
            outline-style: solid;
        }

        .edit-toolbar {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .save-status {
            position: fixed;
            bottom: 20px;
            left: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            display: none;
        }
        
        /* Mobile responsive styles */
        @media (max-width: 1023px) {
            .admin-sidebar {
                position: fixed;
                top: 0;
                left: -100%;
                width: 280px;
                height: 100vh;
                z-index: 50;
                transition: left 0.3s ease;
            }
            
            .admin-sidebar.open {
                left: 0;
            }
            
            .sidebar-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 40;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .sidebar-overlay.open {
                opacity: 1;
                visibility: visible;
            }
        }
    </style>
</head>
<body class="bg-gray-50 font-['Inter']">
    <!-- Mobile Sidebar Overlay -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden"></div>
    
    <div class="flex h-screen">
        <!-- Include Sidebar -->
        <?php 
        $currentPage = 'about-us';
        include 'includes/sidebar.php'; 
        ?>
        
        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Include Header -->
            <?php 
            $pageTitle = 'About Us';
            include 'includes/header.php'; 
            ?>
            
            <!-- Content Area -->
            <main class="content-area flex-1 overflow-y-auto bg-white">

<div class="edit-toolbar">
    <button onclick="saveAllChanges()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
        Save All Changes
    </button>
    <div class="save-status" id="saveStatus"></div>
</div>

<!-- Editable Hero Section -->
<section class="relative min-h-screen flex items-center justify-center overflow-hidden">
    <div class="absolute inset-0 bg-black opacity-20"></div>
    <div class="absolute inset-0 parallax-bg" 
         style="background-image: url('<?= htmlspecialchars($aboutContent['hero']['background_image'] ?? '../images/hero.webp') ?>');"
         data-content-key="hero.background_image"
         contenteditable="false">
    </div>
    
    <div class="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 class="text-6xl md:text-8xl font-black mb-6">
            <span class="text-gradient" 
                  data-content-key="hero.title_line1"
                  contenteditable="true">
                <?= htmlspecialchars($aboutContent['hero']['title_line1'] ?? 'ABOUT') ?>
            </span>
            <br>
            <span class="text-white"
                  data-content-key="hero.title_line2"
                  contenteditable="true">
                <?= htmlspecialchars($aboutContent['hero']['title_line2'] ?? 'BEAM') ?>
            </span>
        </h1>
        <p class="text-xl md:text-2xl text-white mb-8"
           data-content-key="hero.subtitle"
           contenteditable="true">
            <?= htmlspecialchars($aboutContent['hero']['subtitle'] ?? 'Crafting the future of fashion, one thread at a time') ?>
        </p>
        <div>
            <div class="inline-block bg-white text-black px-8 py-4 font-bold uppercase tracking-wider hover:bg-gray-100 transition-all duration-300 hover-lift">
                <span data-content-key="hero.cta_text"
                      contenteditable="true">
                    <?= htmlspecialchars($aboutContent['hero']['cta_text'] ?? 'Discover Our Story') ?>
                </span>
            </div>
        </div>
    </div>
    
    <!-- Scroll indicator -->
    <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div class="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div class="w-1 h-3 bg-white rounded-full mt-2 animate-bounce"></div>
        </div>
    </div>
</section>

<!-- Story Section -->
<section id="story" class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
                <h2 class="text-5xl md:text-6xl font-black mb-8 text-gradient"
                   data-content-key="story.title"
                   contenteditable="true">
                    <?= htmlspecialchars($aboutContent['story']['title'] ?? 'Our Story') ?>
                </h2>
                <p class="text-lg text-gray-700 mb-6 leading-relaxed"
                   data-content-key="story.paragraph1"
                   contenteditable="true">
                    <?= htmlspecialchars($aboutContent['story']['paragraph1'] ?? 'Born from a passion for innovation and a commitment to excellence, Beam emerged as a revolutionary force in the fashion industry. We believe that clothing is more than just fabric—it\'s a statement, a lifestyle, and an expression of individuality.') ?>
                </p>
                <p class="text-lg text-gray-700 mb-8 leading-relaxed"
                   data-content-key="story.paragraph2"
                   contenteditable="true">
                    <?= htmlspecialchars($aboutContent['story']['paragraph2'] ?? 'Founded in 2020, our journey began with a simple vision: to create clothing that transcends trends and speaks to the soul of the modern individual. Every piece we design carries the weight of our values—quality, sustainability, and timeless elegance.') ?>
                </p>
                <div class="border-gradient">
                    <div class="p-6">
                        <p class="text-xl font-bold text-center"
                           data-content-key="story.quote"
                           contenteditable="true">
                            "<?= htmlspecialchars($aboutContent['story']['quote'] ?? 'Fashion is not just about looking good, it\'s about feeling powerful.') ?>"
                        </p>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="relative">
                    <div class="w-full h-96 bg-gray-200 rounded-lg overflow-hidden">
                        <img src="<?= htmlspecialchars($aboutContent['story']['image'] ?? '../images/collection1.webp') ?>" alt="Our Story" class="w-full h-full object-cover"
                             data-content-key="story.image"
                             contenteditable="false">
                    </div>
                    <div class="absolute -bottom-6 -right-6 w-48 h-48 bg-black rounded-lg flex items-center justify-center">
                        <div class="text-center text-white">
                            <div class="text-3xl font-black"
                                 data-content-key="story.year"
                                 contenteditable="true">
                                <?= htmlspecialchars($aboutContent['story']['year'] ?? '2020') ?>
                            </div>
                            <div class="text-sm uppercase tracking-wider"
                                 data-content-key="story.year_label"
                                 contenteditable="true">
                                <?= htmlspecialchars($aboutContent['story']['year_label'] ?? 'Founded') ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision Section -->
<section class="py-20 bg-black text-white">
    <div class="max-w-7xl mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-5xl md:text-6xl font-black mb-4"
                data-content-key="mission_vision.title"
                contenteditable="true">
                <?= htmlspecialchars($aboutContent['mission_vision']['title'] ?? 'Mission & Vision') ?>
            </h2>
            <p class="text-xl text-gray-300 max-w-3xl mx-auto"
               data-content-key="mission_vision.subtitle"
               contenteditable="true">
                <?= htmlspecialchars($aboutContent['mission_vision']['subtitle'] ?? 'We\'re not just creating clothes—we\'re crafting experiences that empower individuals to express their authentic selves.') ?>
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div class="hover-lift">
                <div class="bg-white text-black p-8 rounded-lg h-full">
                    <div class="text-6xl font-black mb-4 text-gradient"
                         data-content-key="mission_vision.mission_number"
                         contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['mission_number'] ?? '01') ?>
                    </div>
                    <h3 class="text-2xl font-bold mb-4"
                        data-content-key="mission_vision.mission_title"
                        contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['mission_title'] ?? 'Our Mission') ?>
                    </h3>
                    <p class="text-gray-700 leading-relaxed"
                       data-content-key="mission_vision.mission_content"
                       contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['mission_content'] ?? 'To revolutionize the fashion industry by creating sustainable, high-quality clothing that empowers individuals to express their unique identity while maintaining the highest standards of craftsmanship and ethical production.') ?>
                    </p>
                </div>
            </div>
            
            <div class="hover-lift">
                <div class="bg-white text-black p-8 rounded-lg h-full">
                    <div class="text-6xl font-black mb-4 text-gradient"
                         data-content-key="mission_vision.vision_number"
                         contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['vision_number'] ?? '02') ?>
                    </div>
                    <h3 class="text-2xl font-bold mb-4"
                        data-content-key="mission_vision.vision_title"
                        contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['vision_title'] ?? 'Our Vision') ?>
                    </h3>
                    <p class="text-gray-700 leading-relaxed"
                       data-content-key="mission_vision.vision_content"
                       contenteditable="true">
                        <?= htmlspecialchars($aboutContent['mission_vision']['vision_content'] ?? 'To become the global leader in sustainable fashion, setting new standards for quality, innovation, and social responsibility while inspiring a new generation of conscious consumers.') ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
                <div class="stats-counter mb-2"
                     data-content-key="stats.countries_number"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['countries_number'] ?? '50') ?>
                </div>
                <div class="text-lg font-semibold text-gray-700"
                     data-content-key="stats.countries_label"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['countries_label'] ?? 'Countries') ?>
                </div>
            </div>
            <div>
                <div class="stats-counter mb-2"
                     data-content-key="stats.products_number"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['products_number'] ?? '1000') ?>
                </div>
                <div class="text-lg font-semibold text-gray-700"
                     data-content-key="stats.products_label"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['products_label'] ?? 'Products') ?>
                </div>
            </div>
            <div>
                <div class="stats-counter mb-2"
                     data-content-key="stats.customers_number"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['customers_number'] ?? '10000') ?>
                </div>
                <div class="text-lg font-semibold text-gray-700"
                     data-content-key="stats.customers_label"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['customers_label'] ?? 'Happy Customers') ?>
                </div>
            </div>
            <div>
                <div class="stats-counter mb-2"
                     data-content-key="stats.years_number"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['years_number'] ?? '5') ?>
                </div>
                <div class="text-lg font-semibold text-gray-700"
                     data-content-key="stats.years_label"
                     contenteditable="true">
                    <?= htmlspecialchars($aboutContent['stats']['years_label'] ?? 'Years') ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Values Section -->
<section class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4">
        <div class="text-center mb-16">
            <h2 class="text-5xl md:text-6xl font-black mb-4"
                data-content-key="values.title"
                contenteditable="true">
                <?= htmlspecialchars($aboutContent['values']['title'] ?? 'Our Values') ?>
            </h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto"
               data-content-key="values.subtitle"
               contenteditable="true">
                <?= htmlspecialchars($aboutContent['values']['subtitle'] ?? 'These core principles guide everything we do, from design to delivery.') ?>
            </p>
        </div>
    </div>
</section>

<script>
const apiEndpoint = '../ajax_handler.php?action=update_content';

document.querySelectorAll('[contenteditable="true"]').forEach(element => {
    element.addEventListener('blur', function() {
        const contentKey = this.dataset.contentKey;
        const newContent = this.innerText;
        
        fetch(apiEndpoint, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                key: contentKey,
                value: newContent
            })
        })
        .then(response => response.json())
        .then(data => {
            showStatus('Changes saved successfully', 'bg-green-500');
        })
        .catch(error => {
            showStatus('Error saving changes', 'bg-red-500');
        });
    });
});

function saveAllChanges() {
    // Get all editable elements
    const editableElements = document.querySelectorAll('[contenteditable="true"]');
    let savedCount = 0;
    let errorCount = 0;
    
    // Show saving status
    showStatus('Saving all changes...', 'bg-blue-500');
    
    // Create promises for all save operations
    const savePromises = Array.from(editableElements).map(element => {
        const contentKey = element.dataset.contentKey;
        const newContent = element.innerText.trim();
        
        return fetch(apiEndpoint, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                key: contentKey,
                value: newContent
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                savedCount++;
            } else {
                errorCount++;
            }
            return data;
        })
        .catch(error => {
            errorCount++;
            return error;
        });
    });
    
    // Wait for all save operations to complete
    Promise.all(savePromises)
        .then(() => {
            if (errorCount === 0) {
                showStatus(`All changes saved successfully (${savedCount} items)`, 'bg-green-500');
            } else {
                showStatus(`Saved ${savedCount} items, ${errorCount} errors`, 'bg-yellow-500');
            }
        })
        .catch(() => {
            showStatus('Error saving changes', 'bg-red-500');
        });
}

function showStatus(message, bgClass) {
    const statusDiv = document.getElementById('saveStatus');
    statusDiv.className = `save-status ${bgClass}`;
    statusDiv.textContent = message;
    statusDiv.style.display = 'block';
    setTimeout(() => statusDiv.style.display = 'none', 3000);
}
</script>

        </main>
    </div>
</div>
    
<script>
    // Sidebar toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        const sidebarToggle = document.getElementById('sidebar-toggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        
        if (sidebarToggle && sidebar && sidebarOverlay) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
                sidebarOverlay.classList.toggle('hidden');
            });
            
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.add('hidden');
            });
        }
    });
</script>
</body>
</html>